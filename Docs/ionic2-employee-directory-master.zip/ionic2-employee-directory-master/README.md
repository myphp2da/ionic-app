## Employee Directory with Ionic 2

To build this project locally:

1. Use the ionic cli to create a new project (More details [here](http://ionicframework.com/docs/v2/getting-started/installation/))
1. Replace the www directory with the www directory available here