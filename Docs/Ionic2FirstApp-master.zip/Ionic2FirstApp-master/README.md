### This is a Ionic 2 tutorial example made for http://www.gajotres.net/ionic-2-tutorial-lets-create-our-first-application/

Follow these instruction to deploy this example:

1. git clone https://github.com/Gajotres/Ionic2FirstApp.git
2. cd Ionic2FirstApp
3. ionic platform add android
4. cordova plugin add cordova-plugin-whitelist
5. npm install
6. ionic serve -> To see if everything is working as it should
7. ionic run android -l -c -s